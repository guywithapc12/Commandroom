DIR=$(dirname "$(readlink -f "$0")")

# Open terminal and run the script
gnome-terminal -- bash -c "python3 \"$DIR/index.py\"; exec bash" &

# Wait for terminal to open
sleep 1

# Maximize the active terminal window
wmctrl -r :ACTIVE: -b add,maximized_vert,maximized_horz