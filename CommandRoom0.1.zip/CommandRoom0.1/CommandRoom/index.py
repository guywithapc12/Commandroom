import blessed
import os
import sys
#Finding the path of this right now
current_dir = os.path.dirname(os.path.abspath(__file__))
#Finding the path of everything else
journal_path = os.path.join(current_dir, 'journal.py')
#new_script = os.path.join(current_dir, 'other_script.py')
#new_script = os.path.join(current_dir, 'other_script.py')

#initiating the terminal
term=blessed.Terminal()

#Makes everything amber
print(term.clear())
print(term.color(214))

#declaring starting marks
c1="*"
c2=""
c3=""
selector=0

#definging my selector function
def slide(ud):
    global c1, c2, c3, selector
    if c1=="*":
        if ud=="down":
            c1=""
            c2="*"
            selector=selector+1
    elif c2=="*":
        if ud=="up":
            c2=""
            c1="*"
            selector=selector-1
        if ud=="down":
            c2=""
            c3="*"
            selector=selector+1
    elif c3=="*":
        if ud=="up":
            c3=""
            c2="*"
            selector=selector-1

#The main interface backend
def captinp():
    global c1, c2, c3, selector
    with term.cbreak(), term.hidden_cursor():
        print(term.color(214))
        while True:
            inp=term.inkey()
            if inp =="w":
                if selector>0:
                    slide("up")
                    print_screen()
                    
            elif inp=="s":
                if selector<3:
                    slide("down")
                    print_screen()
            elif inp=="\n":
                if selector==0:
                    #journal=journal.py
                    os.execv(sys.executable, [sys.executable, journal_path])
                elif selector==1:
                    print('not yet implemented')
                elif selector==2:
                    print('not yet implemented')

logo=r'''                  ___     ___
                 /\__\   /\  \    
                /:/  /  /::\  \   
               /:/  /  /:/\:\__\  
              /:/  /  /:/ /:/  /  
             /:/__/  /:/_/:/__/___
             \:\  \ / :\/:::::/  /
              \:\  /:/\::/~~/~~~~ 
               \:\/:/  \:\~~\     
                \::/  / \:\__\    
                 \/__/   \/__/    '''
#This is my graphical interface
def print_screen():
    global c1, c2, c3, selector
    print(term.clear())
    intromsg=f'''

                    !!!WIP!!!

{logo}



            Welcome to Control Room!

        Please select a sub application

                    !!!WIP!!!

          Journal {c1}

             Diet {c2}
                
          Workout {c3}
'''
    print(intromsg,)

#This gets the ball rolling
print_screen()
captinp()
