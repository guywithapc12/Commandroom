import blessed
import os
import sys
import datetime
import csv
from datetime import date

#Finding the path of this right now
current_dir = os.path.dirname(os.path.abspath(__file__))
#Finding the path of index
index_path = os.path.join(current_dir, 'index.py')


#initiating the terminal
term=blessed.Terminal()

#Makes everything amber
print(term.clear())
print(term.color(214))

#Making a fuction to edit csv files
def editcurinfo(newlist):
    #Reads and makes a last to compare
    with open('jcurrentinfo.csv', 'r') as current:
        reader = csv.reader(current)
        cleaned_rows = []
        for row in reader:
            # Strip quotes from each cell in the row
            cleaned_row = [cell.strip("'\"") for cell in row]
            # Convert to int if possible
            cleaned_row = [int(x) if x.isdigit() else x for x in cleaned_row]
            cleaned_rows.append(cleaned_row)
        cleaned_rows[1]=newlist

    # Overwrites with newlist
    with open('jcurrentinfo.csv', 'w', newline='') as current:
        writer = csv.writer(current)
        writer.writerows(cleaned_rows)  # Write all cleaned rows back
        
#Returns a list copy of currentinfo
def getcurinfo():
    with open('jcurrentinfo.csv', 'r') as current:
        reader=csv.reader(current)
        next(reader)
        #turns the bitch into a parsable list
        thecsv=next(reader)
        #!should output only the second line
        cleaned_row = [cell.strip("'\"") for cell in thecsv]
        #!debugging print
        treturn=[int(x) if x.isdigit() else x for x in cleaned_row]
        
        return treturn

#Returns the actual entry information
def getformat():
    with open('jformat.csv', 'r') as current:
        reader=csv.reader(current)
        thecsv=list(reader)
        return thecsv
def monthlycheckup():
    curinfo=getcurinfo()
    supposedmonth=curinfo[1]
    currentmonth=date.today().month
    test=curinfo[2]
    if supposedmonth!=currentmonth or os.path.exists("j"+str(test)+".csv")!=True:
        #Makes new csv file
        title=curinfo[2]+1
        title=str(title)
        title=str(title)
        newtext=open("j"+title+'.csv','w',newline='')
        newtext.close()
        #updates curinfo
        curinfo[1]=currentmonth
        curinfo[2]=curinfo[2]+1
        editcurinfo(curinfo)
        print("!!newmonthtrigger!!")




#Stores info about the UI
selector=0
I1=["*"," "," "]
def get_indexscr():
    indexscr=f"""


                        This is the Journal Function.
                        would you like to:


                        Make a new entry  {I1[0]}

                        View an entry     {I1[1]}

                        Delete an entry   {I1[2]}

                        press q to save and exit

    """
    return indexscr
#Much better nav system than I made in index. Copy from this one and not index for future
def indexnav(direction):
    global selector
    global I1
    if direction=="up":
        if selector!=0:
             newpos=selector-1
             I1[newpos]=I1[selector]
             I1[selector]=" "
             selector=selector-1
    if direction=="down":
         if selector!=2:
            newpos=selector+1
            I1[newpos]=I1[selector]
            I1[selector]=" "
            selector=selector+1
    print(term.clear())
    print(get_indexscr())
#These are my two entry creation screens
N1=""

writeascii=r'''

      _________      ,.
     /^\       \    ''=\
     \@/_______/     '=;\
      \ ~~~~~~ \       ="\
       \ ~~~~~~ \       '=\
      /^\ ~~~~~~ \        '\   
      \_/________/          ? 



'''
def get_nentryscr1():
    return f"""
        {writeascii}

            Please Name Your Entry:

    Title={N1+'|'}

"""
N2=""
def get_nentryscr2():
    return f"""
                Press the "~" key to save and exit

            Please Write Your Entry:
    {N2+'|'}



        """
#This is the screen for selecting journal entries
L1=""
Labove=""
Lbelow=""
def get_entrylist():
    return f'''
                        Select Entry:
{Labove}
{"===>"+L1+"<==="}
{Lbelow}
    
'''
#This will tell what index my selector is on for ACTIVATION
listselector=0
#This sets everything up initially in terms of the list for the GUI as well as giving out the list
def parselist():
    global L1
    global Lbelow
    format=getformat()
    list=[]
    if format:
        for x in format:
            list.append([x[4],x[3]])
        L1=str(list[0][0])+": "+str(list[0][1])
        below=''
        list2=list[1:]
        counter=0
        for x in list2:
            counter+=1
            below=below+str(x[0])+': '+str(x[1])+"\n"
            if counter==20:
                break
        Lbelow=below
    return list
#This is the nav function for the list screen. I hope I never have to make another function with so many arguements again.
def listnav(direction, liabove, li, libelow, forlength):
    global L1
    global Labove
    global Lbelow
    global listselector
    if direction=="up":
        if liabove and listselector!=0:
            listselector=listselector-1
            libelow=[li]+libelow
            li=liabove[-1]
            liabove=liabove[:-1]
            L1=""
            Labove=""
            Lbelow=""
            for x in liabove[-20:]:
                Labove=Labove+str(x[0])+": "+str(x[1])+"\n"
            L1=str(li[0])+": "+str(li[1])
            for x in libelow[:20]:
                Lbelow=Lbelow+str(x[0])+': '+str(x[1])+'\n'
    if direction=="down":
        if libelow and listselector < len(forlength)-1:
            
            listselector=listselector+1
            liabove=liabove+[li]
            li=libelow[0]
            libelow=libelow[1:]
            L1=""
            Labove=""
            Lbelow=""
            
            for x in liabove[-20:]:
                
                Labove=Labove+str(x[0])+": "+str(x[1])+"\n"
            L1=str(li[0])+": "+str(li[1])
            
            for x in libelow[:20]:
                
                Lbelow=Lbelow+str(x[0])+': '+str(x[1])+'\n'
    return libelow, li, liabove
#!ACHTUNG! Tack this bish onto anything that alters the number of shiz in mah nizzle
li=parselist()
if li:
    txtabove=''
    txtbelow=''
    selected=''
    listabove=[]
    lis=li[0]
    listbelow=li[1:]
#!ACHTUNG!
V1=''
V2=''
viewascii=r'''
     _________
     /^\       \  
     \@/_______/
      \ ~~~~~~ \ 
       \ ~~~~~~ \ 
      /^\ ~~~~~~ \ 
      \_/________/
      '''
def get_view():
    return f'''
     {viewascii}
Press q to exit

{"Title: "+V1}


     {V2}
'''
def delete(selector):
    #deletes the entry
    form=getformat()
    docnum=form[selector][0]
    
    with open('j'+docnum+'.csv') as current:
        reader=csv.reader(current, delimiter="|")
        entry=list(reader)
    
    entrynum =form[selector][4]
    indexcounter=0
    for x in entry:
        if x[0]==entrynum:
            
            del entry[indexcounter]
            break
        indexcounter+=1
    with open('j'+docnum+'.csv','w') as current:
        writer=csv.writer(current, delimiter="|")
        writer.writerows(entry)
    #deletes the info in format
    del form[selector]
    with open ('jformat.csv','w') as current:
        writer=csv.writer(current)
        writer.writerows(form)
    #updates curinfo
    inf=getcurinfo()
    inf[4]=inf[4]-1

delascii=r'''
      _________         /\        
     /^\       \       |  |
     \@/_______/       \@@/
      \ ~~~~~~ \         \\
       \ ~~~~~~ \         \\
      /^\ ~~~~~~ \         \\
      \_/________/          \\ 
'''
def get_delete():
    return f'''
    {delascii}

Press q to exit

!WARNING. THIS WILL DELETE THE TEXT PERMANENTLY! 
Press the '~' key to delete.

{"Title: "+V1}


     {V2}


'''








##!!!IMPORTANT SHIT ZONE!!!
delete1=False
#Stores what tab the user is on, for when the loop cycles through.
screen="index"
#Main Control loop that does EVERYTHING. Captures user inputs
with term.cbreak(), term.hidden_cursor():
        while True:
            print(term.color(214))

            if screen=="index":
                print(term.clear())
                print(get_indexscr())
                inp=term.inkey()
                #Soglad I improved the nav sysetem
                if inp =="w":
                        indexnav("up")
                elif inp=="s":
                        indexnav("down")
                elif inp=="q":
                    os.execv(sys.executable, [sys.executable, index_path])
                elif inp=="\n":
                    if selector==0:
                        screen="newentry1"
                        selector=0
                    elif selector==1:
                        #this one is view
                        li=parselist()
                        if li:
                            screen="view/delete"
                            delete1=False
                            selector=0
                        else:
                            print("There are no entries available.")
                    elif selector==2:
                        #this one is delete
                        li=parselist()
                        if li:
                            screen="view/delete"
                            delete1=True
                            selector=0
                        else:
                            print("There are no entries available.")
            elif screen=="newentry1":
                print(term.clear())
                print(get_nentryscr1())
                inp=term.inkey()
                if inp=="\n":
                    monthlycheckup()
                    screen="newentry2"
                elif inp.name == 'KEY_BACKSPACE' or inp == '\x08' or inp == '\x7f':
                    N1=N1[:-1]
                elif inp:
                    N1=str(N1+inp)
            elif screen=="newentry2":
                print(term.clear())
                print(get_nentryscr2())
                inp=term.inkey()
                if inp=='`':
                    currinfo=getcurinfo()
                    entrynum=currinfo[4]+1
                    currinfo[4]=currinfo[4]+1
                    N2.replace('\n', '"\n"')
                    N2=[str(i).replace('\n', '\\n') for i in N2]
                    newentry=[entrynum,N1,N2]
                    #Actually writes the damn thing
                    with open('j'+str(currinfo[2])+'.csv','a', newline='') as current:
                        writer=csv.writer(current, delimiter='|')
                        writer.writerow(newentry)
                    #Updates currinfo
                    editcurinfo(currinfo)
                    #Places the entry into the log
                    newform=[currinfo[2],date.today(),date.today().month,str(N1),entrynum]
                    with open('jformat.csv','a') as current:
                        writer=csv.writer(current)
                        writer.writerow(newform)
                    N1=''
                    N2=''
                    #!This block saves everything for view/delete
                    li=parselist()
                    if li:
                        txtabove=''
                        txtbelow=''
                        selected=''
                        listabove=[]
                        lis=li[0]
                        listbelow=li[1:]
                    #!This block saves everything for view/delete
                    selector=0
                    listselector=0
                    I1=['*','','']
                    screen="index"
                elif inp.name == 'KEY_BACKSPACE' or inp == '\x08' or inp == '\x7f':
                    N2=N2[:-1]
                elif inp:
                    N2=str(N2+inp)
            elif screen=="view/delete":
                #!use this later for graphic
                print(term.clear())
                print(get_entrylist())
                inp=term.inkey()
                if inp=="w":
                    listbelow, lis, listabove=listnav("up",listabove,lis, listbelow,li)
                if inp=="s":
                    listbelow, lis, listabove=listnav("down",listabove,lis,listbelow,li)
                if inp=="\n":
                    if delete1==False:
                        
                        screen="view"
                    if delete1==True:
                        
                        screen="delete1"
            elif screen=="view":
                print(term.clear())
                print(get_view())
                #Gets the title
                cui=getcurinfo()
                cui=cui[2]
                with open('j'+str(cui)+'.csv') as current:
                    reader = csv.reader(current, delimiter='|')
                    cui2=list(reader)
                V1=''
                V1=str(cui2[listselector][1])
                
                thedamnc=cui2[listselector][2]
                #!WILL NOT FUCKING JOIN
               
                import ast
                entry = ast.literal_eval(cui2[listselector][2])
                V2 = ''.join(entry).replace('\\n', '\n')
                #End pirated chatgpt code

                #Failed try:
                #V2=''
                #for i in cui2[listselector][2]:
                #    V2=V2+str(i)
                
                print(term.clear())
                print(get_view())
                #Exit option
                inp=term.inkey()
                if inp=="q":
                    selector=0
                    listselector=0
                    I1=['*','','']
                    screen="index"
           
            elif screen=="delete1":
                print(term.clear())
                print(get_delete())
                #Gets the title
                cui=getcurinfo()
                cui=cui[2]
                with open('j'+str(cui)+'.csv') as current:
                    reader = csv.reader(current, delimiter='|')
                    cui2=list(reader)
                V1=''
                V1=str(cui2[listselector][1])
                
                #Gets the text
                thedamnc=cui2[listselector][2]
                #Thank you genie:
                import ast
                entry = ast.literal_eval(cui2[listselector][2])
                V2 = ''.join(entry).replace('\\n', '\n')
                #End pirated chatgpt code

                
                print(term.clear())
                print(get_delete())
                #Exit option
                inp=term.inkey()
                if inp=="q":
                    selector=0
                    listselector=0
                    I1=['*','','']
                    screen="index"
                if inp=="`":
                    delete(listselector)
                    li=parselist()
                    #!NEED for updating
                    txtabove=''
                    txtbelow=''
                    selected=''
                    #Chatgpt code(technically mine from earlier, but it suggested using it here)
                    listselector = 0
                    if li:
                        lis = li[0]
                        listabove = []
                        listbelow = li[1:]

                    L1 = str(lis[0]) + ": " + str(lis[1]) if len(lis) > 1 else str(lis)
                    Labove = ''
                    Lbelow = '\n'.join(str(x[0]) + ': ' + str(x[1]) for x in listbelow[:20])
                    #End chatgpt code
                    if li:
                        listabove=[]
                        lis=li[0]
                        listbelow=li[1:]
                    #!Need for updating
                    selector=0
                    I1=['*','','']
                    listselector=0
                    screen='index'





